import pyparsing
pyparsing.show_best_practices()
